SkillHub Windows package for OpenClaw

1. Run install-skillhub-openclaw-windows.ps1 in PowerShell.
2. Verify: skillhub --help
3. Install Tavily: skillhub install tavily-search
4. Configure TAVILY_API_KEY
5. Restart OpenClaw gateway

This package contains:
- SkillHub runtime
- OpenClaw SkillHub plugin
- Windows command shims

