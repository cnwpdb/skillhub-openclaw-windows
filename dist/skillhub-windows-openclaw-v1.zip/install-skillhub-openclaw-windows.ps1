$ErrorActionPreference = "Stop"

$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$runtimeSource = Join-Path $packageRoot "runtime"
$pluginSource = Join-Path $packageRoot "plugin"
$binSource = Join-Path $packageRoot "bin"

$skillhubHome = Join-Path $env:USERPROFILE ".skillhub"
$pluginTarget = Join-Path $env:USERPROFILE ".openclaw\\extensions\\skillhub"
$npmBin = Join-Path $env:APPDATA "npm"

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
  throw "Python 3 is required. Please install Python first."
}

New-Item -ItemType Directory -Force $skillhubHome | Out-Null
New-Item -ItemType Directory -Force $pluginTarget | Out-Null
New-Item -ItemType Directory -Force $npmBin | Out-Null

Copy-Item (Join-Path $runtimeSource "*") $skillhubHome -Recurse -Force
Copy-Item (Join-Path $pluginSource "*") $pluginTarget -Recurse -Force
Copy-Item (Join-Path $binSource "skillhub.cmd") (Join-Path $npmBin "skillhub.cmd") -Force
Copy-Item (Join-Path $binSource "clawhub.cmd") (Join-Path $npmBin "clawhub.cmd") -Force

$openclawCmd = Join-Path $npmBin "openclaw.cmd"
if (Test-Path $openclawCmd) {
  & $openclawCmd config set "plugins.entries.skillhub.enabled" true
  & $openclawCmd config set "plugins.entries.skillhub.config.primaryCli" skillhub
  & $openclawCmd config set "plugins.entries.skillhub.config.fallbackCli" clawhub
  & $openclawCmd config set "plugins.entries.skillhub.config.primaryLabel" cn-optimized
  & $openclawCmd config set "plugins.entries.skillhub.config.fallbackLabel" public-registry
}

Write-Host ""
Write-Host "SkillHub Windows package installed."
Write-Host "Next steps:"
Write-Host "1. Restart your terminal or refresh PATH."
Write-Host "2. Run: skillhub --help"
Write-Host "3. Run: skillhub install tavily-search"
Write-Host "4. Configure TAVILY_API_KEY"

